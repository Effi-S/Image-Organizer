﻿//#include <iostream>
//#include <string>
//#include <filesystem>
//#include <fstream>
//#include <vector>
//#include <memory>
//#include <unordered_set>
//#include <ctime>
//
//namespace fs = std::filesystem;
//
//int main()
//{
//	std::clock_t start(std::clock());
//	std::cout << "\n\n\n\nStarting Run:\n";
//	//std::u16string path = u"D:\\cpp projects\\proj2020\\אא";
//	std::wstring path = L"C:\\";
//	
//	std::vector<std::unique_ptr<fs::directory_entry>> images_db;
//
//	std::unordered_set<std::string> extension_set({".png", ".jpg", ".jpeg", "bmp"});
//
//	for (const auto& entry : fs::recursive_directory_iterator(path, fs::directory_options::skip_permission_denied))
//	{
//		std::string extension = entry.path().extension().string();
//		if (extension_set.find(extension) != extension_set.end())
//			images_db.push_back(std::make_unique<fs::directory_entry>(entry));
//	}
//
//	typedef std::basic_ofstream<std::u16string::value_type> u16ofstream;
//	u16ofstream file("C:/Users/effi/Desktop/temp/t.txt", std::ios_base::app);
//
//	for (const auto& entry : images_db)
//		try {
//		file << entry->path().filename().u16string() << std::endl;
//	}
//	catch(...){
//		//file << entry.get() << std::endl;
//	}
//
//	std::cout << "Number Of images Found:" << images_db.size() << std::endl
//		<< "Time it took: " << (double)std::clock() - start;
//	
//}