#include <opencv2/opencv.hpp>
#include <iostream>
#include <string>
#include <memory>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <filesystem>
#include "pHash.h"


namespace fs = std::filesystem;

typedef cv::Mat ImKey;
typedef cv::Mat SmlImg;
typedef std::pair<SmlImg, fs::path> ImgInfo;
typedef std::vector<ImgInfo> ImgInfoList;
typedef std::unordered_map<int, ImgInfoList> ImgMap;

const std::unordered_set<std::string>
file_formats = { ".png", ".jpg", ".bmp", ".gif" , ".svg" };


ImgMap getImgMap(const std::string& path) {

	std::cout << "Formats:";
	for (auto x : file_formats)
		std::cout << x << " ";
	std::cout << std::endl;

	ImgMap map;
	int i = 1;
	for (auto& itEntry : fs::recursive_directory_iterator(path, fs::directory_options::skip_permission_denied)) {
		try {
			if (!itEntry.is_regular_file())continue;
			std::string name(itEntry.path().extension().string());
			std::string  file_end = itEntry.path().extension().string();
			std::cout << i;
			auto it = file_formats.find(file_end);
			
			if (it != file_formats.cend())
			{
				std::cout << file_end << " IN formats \n";
				//auto curr_path = itEntry.path().native();
				//auto img = cv::imread(curr_path, cv::IMREAD_GRAYSCALE);
				/*uint64_t key = std::hash<cv::Mat>()
				if(map.find())
				map.emplace*/
			}
			else
				std::cout << " [" << file_end << "] " << " NOT in formats \n";

			//std::cout << "dir:" << i << "  " <<name  << '\n';

			//map.emplace();
			i++;
		}
		catch (fs::filesystem_error & e) {
			std::cout << i << "issue reading:" << e.what() << std::endl; i++;
		}
		catch (std::system_error & e) {
			std::cout << i << "issue :" << e.what() << std::endl; i++;
		}
		catch (std::exception & e) { std::cout << i << " unknown issue :" << e.what() << std::endl; i++; }
		catch (...) {
			std::cout << "unknown error\n"; i++;
		};
	}
	return map;
}


int main(int argc, char** argv)
{

	for (int i = 1; i < argc; i++)
		std::cout << "Running Basic Compare in folder:"
		<< argv[i] << std::endl;

	auto map = std::move(getImgMap(argv[1]));

	//// Read the image file
	//cv::Mat image1 = cv::imread("C:/Users/effi/Desktop/temp/player_01.png"/*, cv::IMREAD_GRAYSCALE*/);
	//cv::Mat image2 = cv::imread("C:/Users/effi/Desktop/temp/loading.png"/*, cv::IMREAD_GRAYSCALE*/);

	////creating small pics
	//cv::Mat img1(1, 100, CV_8UC1, cv::Scalar(50, 125, 30));
	//cv::Mat img2(1, 100, CV_8UC1, cv::Scalar(50, 125, 30));

	////converting loaded images to smaller types
	//image1.convertTo(img1, 0, 1, 1);
	//image2.convertTo(img2, 0, 1, 1);

	//if (image1.empty() || image2.empty() || img1.empty() || img2.empty()) // Check for failure
	//{
	//	std::cout << "Could not open or find the image" << std::endl;
	//	std::system("pause"); //wait for any key press
	//	return -1;
	//}

	/*std::string window1 = "pic1window";
	std::string window2 = "pic2window";
	std::string wind1 = "small_pic1window";
	std::string wind2 = "small_pic2window";*/

	/*cv::namedWindow(window1, cv::WINDOW_GUI_EXPANDED);
	cv::namedWindow(window2, cv::WINDOW_GUI_EXPANDED);
	cv::namedWindow(wind1, cv::WINDOW_GUI_EXPANDED);
	cv::namedWindow(wind2, cv::WINDOW_GUI_EXPANDED);*/

	//cv::imshow(window1, image1);
	//cv::imshow(window2, image2); // Show our image inside the created window.
	//cv::imshow(wind1, img1);
	//cv::imshow(wind2, img2);

	run();


	cv::waitKey(0); // Wait for any keystroke in the window

	//cv::destroyWindow(window1); //destroy the created windows
	//cv::destroyWindow(window2);
	//cv::destroyWindow(wind1); //destroy the created windows
	//cv::destroyWindow(wind2);
	return 0;
}

