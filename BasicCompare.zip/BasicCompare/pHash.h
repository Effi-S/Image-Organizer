#pragma once
#include <opencv2/core.hpp>
#include <opencv2/core/ocl.hpp>
#include <opencv2/highgui.hpp>
//#include <opencv2/img_hash.hpp>
#include <opencv2/img_hash/img_hash_base.hpp>
#include <opencv2/img_hash/phash.hpp>
#include <opencv2/img_hash/radial_variance_hash.hpp>
#include <opencv2/img_hash/average_hash.hpp>
#include <opencv2/img_hash/color_moment_hash.hpp>
#include <opencv2/img_hash/block_mean_hash.hpp>
#include <opencv2/img_hash/marr_hildreth_hash.hpp>
#include <opencv2/imgproc.hpp>

#include <iostream>

void computeHash(cv::Ptr<cv::img_hash::ImgHashBase> algo)
{
	cv::Mat const input = cv::imread("C:/Users/effi/Desktop/temp/BossBall2.png");
	cv::Mat const target = cv::imread("C:/Users/effi/Desktop/temp/BossBall.png");

	cv::Mat inHash; //hash of input image
	cv::Mat targetHash; //hash of target image
	
	//comupte hash of input and target
	algo->compute(input, inHash);
	algo->compute(target, targetHash);
	//Compare the similarity of inHash and targetHash
	//recommended thresholds are written in the header files
	//of every classes
	double const mismatch = algo->compare(inHash, targetHash);
	std::cout<<"The Match output:" << mismatch << std::endl;

	std::string window1 = "pic1window";
	std::string window2 = "pic2window";
	std::string wind1 = "small_pic1window";
	std::string wind2 = "small_pic2window";

	cv::namedWindow(window1, cv::WINDOW_GUI_EXPANDED);
	cv::namedWindow(window2, cv::WINDOW_GUI_EXPANDED);
	cv::namedWindow(wind1, cv::WINDOW_GUI_EXPANDED);
	cv::namedWindow(wind2, cv::WINDOW_GUI_EXPANDED);

	cv::imshow(window1, input);
	cv::imshow(window2, inHash); // Show our image inside the created window.
	cv::imshow(wind1, targetHash);
	cv::imshow(wind2, target);

	cv::waitKey(0); // Wait for any keystroke in the window

	cv::destroyWindow(window1); //destroy the created windows
	cv::destroyWindow(window2);
	cv::destroyWindow(wind1); //destroy the created windows
	cv::destroyWindow(wind2);
}

void run()
{
	//disable opencl acceleration may(or may not) boost up speed of img_hash
	cv::ocl::setUseOpenCL(false);

	computeHash(cv::img_hash::AverageHash::create());
	computeHash(cv::img_hash::PHash::create());
	computeHash(cv::img_hash::MarrHildrethHash::create());
	computeHash(cv::img_hash::RadialVarianceHash::create());
	//BlockMeanHash support mode 0 and mode 1, they associate to
	//mode 1 and mode 2 of PHash library
	computeHash(cv::img_hash::BlockMeanHash::create(0));
	computeHash(cv::img_hash::BlockMeanHash::create(1));
	computeHash(cv::img_hash::ColorMomentHash::create());
}