#pragma once
#include "ImageMapMaker.h"

class BitExactCompare :
	public ImageMapMaker
{
public:
	BitExactCompare();	
private:
	//ImgHitMap m_map;
};

