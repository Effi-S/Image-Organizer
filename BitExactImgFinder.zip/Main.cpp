#include "ImgScanner.h"
#include "BitExactImgFinder.h"

int main(){
	ImgScanner scanner(L"C:\\Users\\effi");
	std::cout << "Done reading images\n";
	BitExactImgFinder comp(scanner.m_img_db);
	comp.show();

	return 0;
}
