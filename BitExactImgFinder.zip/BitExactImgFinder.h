#pragma once
#include <unordered_map>
#include <unordered_set>
#include <opencv2/opencv.hpp>
#include<opencv2/img_hash/average_hash.hpp>
#include "ImgScanner.h"
const int BITS = 16;
using HashKey = std::string;
using MatchMap = std::unordered_map<HashKey , std::vector<cv::Mat>>;

class BitExactImgFinder
{
public:
	BitExactImgFinder(IMG_DB& db) :m_img_db(db) { makeSet(); };	
	void show();
private:
	
	void makeSet();
	IMG_DB& m_img_db;
	MatchMap m_matches;

	cv::Ptr<cv::img_hash::ImgHashBase> m_algo;

};

