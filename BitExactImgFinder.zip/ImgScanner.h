#pragma once
#include<iostream>
#include <iostream>
#include <string>
#include <filesystem>
#include <fstream>
#include <vector>
#include <memory>
#include <unordered_set>
#include <ctime>
#include <opencv2/opencv.hpp>
#include <future>
#include <mutex>

namespace fs = std::filesystem;
using IMG_DB = std::vector<cv::Ptr<cv::Mat>>; 

class ImgScanner
{
public:
	ImgScanner(const std::wstring & path = L"C:\\");

	void setPath(const std::wstring& path) {
		m_img_db = std::move(ImgScanner(path).m_img_db);
	}
	
	friend void addImgToDB(ImgScanner* scanner, const std::filesystem::directory_entry& entry);


	 IMG_DB m_img_db;

};

